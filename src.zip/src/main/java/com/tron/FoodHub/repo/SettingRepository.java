package com.tron.FoodHub.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tron.FoodHub.entity.Setting;

public interface SettingRepository extends JpaRepository<Setting,Integer>{

}
